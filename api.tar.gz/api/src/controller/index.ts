import { Request, Response } from "express";
import conection from "./../../database";

class PersonasController {
        public async getPersonas(req:Request,res:Response):Promise<void>{
            conection.query("SELECT * FROM personas;",(error,result)=>{
                if(error) throw res.json({status:"error",information:error});
                res.json({status:"success",information:result,lengthRow:result.length})
            })
        }
}
export default new PersonasController();
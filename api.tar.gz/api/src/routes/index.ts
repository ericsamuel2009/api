import { Router } from "express";
import PersonasController from "./../controller";

class PersonasRouter {
    public router:Router;
    constructor() {
        this.router = Router();
        this.config();
    }
    public config():void{
        this.router.get("/",PersonasController.getPersonas)
    }
}
const personasRouter = new PersonasRouter().router
export default personasRouter;
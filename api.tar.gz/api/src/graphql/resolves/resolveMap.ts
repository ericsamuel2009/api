import { IResolvers } from 'graphql-tools';

const resolver : IResolvers = {
    Query:{
        saludar(){
            return "HOLA"
        },
        personas(){
            return [
                {
                    id: 1,
                    nombre: "eric",
                    apellido: "maldonado",
                    edad: 23,
                    fecha: new Date()
                }
                {
                    id: 2,
                    nombre: "juan",
                    apellido: "mendoza",
                    edad: 30,
                    fecha: new Date()
                }
            ]
        }
    }
}

export default resolver
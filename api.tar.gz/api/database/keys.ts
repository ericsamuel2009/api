export default {
    host: "localhost",
    user: "root",
    password: "",
    database: "prueba",
    post: 3306
}
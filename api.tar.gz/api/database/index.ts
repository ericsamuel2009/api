import mysql from "mysql";
import key from "./keys";

const conection = mysql.createConnection(key);
conection.connect((error)=>{
    if(error) throw console.log(`NO SE CONECTO A LA BASE DE DATOS -> ${error}`);
    console.log(`CONEXION ESTABLECIDA SATISFACTORIAMENTE`)
})

export default conection;
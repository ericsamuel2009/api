import express, { Application } from "express";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";
import { ApolloServer } from "apollo-server-express"
import { schema } from './src/graphql'
dotenv.config()

import personasRoutes from "./src/routes/index";

class Servidor {
    public app:Application;
    constructor(){
        this.app = express();
        this.config();
        this.router();
        this.graphql(this.app)
    }
    private config():void{
        this.app.set("port", process.env.PORT || 3000);
        this.app.use(cors());
        this.app.use(morgan(function (tokens,req,res) {
            return [
                tokens.method(req,res),
                tokens.url(req,res),
                tokens.status(req,res)
            ].join(' ')
        }));
        this.app.use(express.json());
        this.app.use(express.urlencoded({extended : false}))
    }

    private router():void{
        this.app.use("/api/v1.0/personas",personasRoutes)
    } 

    public start():void{        
        this.app.listen(this.app.get("port"), ()=> {
            console.log(`SERVIDOR EJECUTANDO EN -> http://localhost:${this.app.get("port")}`);
            
        })
    }

    public graphql(app:Application):void{
        const apolloServ = new ApolloServer({
            schema,
            playground:true,
            introspection: true
        })
        apolloServ.applyMiddleware({ app })
        console.log(`GRAPHQL EJECUTANDO EN -> http://localhost:${this.app.get("port")}/graphql`);        
    }

}
const servidor = new Servidor();
servidor.start();